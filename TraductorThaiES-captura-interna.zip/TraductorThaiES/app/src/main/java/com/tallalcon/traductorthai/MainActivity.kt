package com.tallalcon.traductorthai

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var level: TextView
    private lateinit var startButton: Button
    private var receiverRegistered = false
    private val projectionRequest = 601
    private val audioPermissionRequest = 602

    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != AudioCaptureService.ACTION_STATUS) return
            status.text = intent.getStringExtra(AudioCaptureService.EXTRA_STATUS) ?: "Captura activa."
            val rms = intent.getIntExtra(AudioCaptureService.EXTRA_LEVEL, 0)
            level.text = when {
                rms < 2 -> "Nivel de audio interno: 0 · No llega sonido todavía"
                else -> "Nivel de audio interno: $rms · Sonido detectado"
            }
            if (intent.getBooleanExtra(AudioCaptureService.EXTRA_STOPPED, false)) {
                startButton.text = "Probar audio interno de TikTok"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val filter = IntentFilter(AudioCaptureService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(captureReceiver, filter)
        receiverRegistered = true
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 28))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        root.addView(label("Traductor Thai → Español", 26f))
        root.addView(label("PRUEBA DE AUDIO INTERNO · SIN MICRÓFONO", 15f, Color.rgb(190, 180, 255)))
        root.addView(label("Esta prueba intenta capturar directamente la reproducción de TikTok, incluso si escuchas con auriculares. Android exige conceder permiso de grabación de audio y confirmar la captura del sistema; la app no usa el micrófono como fuente de sonido.", 15f, Color.LTGRAY))
        status = label("Abre tu directo de TikTok y deja el audio reproduciéndose. Luego vuelve aquí y pulsa el botón.", 15f, Color.rgb(220, 220, 235))
        root.addView(status, matchWidth())
        level = label("Nivel de audio interno: aún no se ha iniciado", 17f, Color.rgb(140, 240, 180))
        root.addView(level, matchWidth())
        startButton = Button(this).apply {
            text = "Probar audio interno de TikTok"
            setOnClickListener { onStartPressed() }
        }
        root.addView(startButton, matchWidth())
        root.addView(Button(this).apply {
            text = "Detener captura"
            setOnClickListener {
                startService(Intent(this@MainActivity, AudioCaptureService::class.java).setAction(AudioCaptureService.ACTION_STOP))
                status.text = "Solicitando detener la captura…"
            }
        }, matchWidth())
        root.addView(label("Importante: esta versión solo comprueba si Android entrega audio interno. Todavía no reconoce ni traduce las palabras; primero debemos verificar que TikTok envíe sonido a la captura.", 14f, Color.LTGRAY), matchWidth())
        setContentView(root)
    }

    private fun onStartPressed() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        requestProjectionPermission()
    }

    private fun requestProjectionPermission() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Uses result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, AudioCaptureService::class.java).apply {
                    action = AudioCaptureService.ACTION_START
                    putExtra(AudioCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
                startButton.text = "Captura iniciada"
                status.text = "Captura autorizada. Vuelve a TikTok y reproduce el directo; después regresa aquí para comprobar el nivel."
            } else status.text = "No autorizaste la captura de pantalla/audio. No se inició la captura."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestProjectionPermission()
            else Toast.makeText(this, "Android requiere este permiso para la API de captura de audio interno; la app no usará el micrófono como fuente.", Toast.LENGTH_LONG).show()
        }
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onDestroy() {
        if (receiverRegistered) try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
