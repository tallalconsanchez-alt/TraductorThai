package com.tallalcon.traductorthai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import kotlin.math.sqrt
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

class AudioCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.tallalcon.traductorthai.START_CAPTURE"
        const val ACTION_STOP = "com.tallalcon.traductorthai.STOP_CAPTURE"
        const val ACTION_STATUS = "com.tallalcon.traductorthai.CAPTURE_STATUS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_STATUS = "status"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_STOPPED = "stopped"
        const val EXTRA_TRANSCRIPT = "transcript"
        private const val CHANNEL_ID = "thai_audio_capture"
        private const val NOTIFICATION_ID = 4110
    }

    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    private var asrThread: Thread? = null
    private var asrEngine: ThaiAsrEngine? = null
    private var asrQueue: ArrayBlockingQueue<ShortArray>? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture("Captura detenida.")
            ACTION_START -> {
                if (running) stopCapture("Reiniciando captura…")
                startForegroundCompat()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data == null || resultCode == 0) {
                    broadcast("No se recibió la autorización de Android.", 0, true)
                    stopSelf()
                    return START_NOT_STICKY
                }
                try {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(resultCode, data)
                    projection?.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() { stopCapture("Android detuvo la autorización de captura.") }
                    }, android.os.Handler(mainLooper))
                    beginAudioRead()
                } catch (e: Exception) {
                    broadcast("No se pudo iniciar la captura interna: ${e.message ?: e.javaClass.simpleName}", 0, true)
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun beginAudioRead() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            broadcast("La captura interna requiere Android 10 o posterior.", 0, true)
            stopSelf(); return
        }
        val p = projection ?: run { broadcast("Falta la sesión de captura.", 0, true); stopSelf(); return }
        val config = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
            .build()
        val sampleRate = 16000
        val channelMask = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding)
        if (minBuffer <= 0) {
            broadcast("Android no pudo preparar el búfer de audio (código $minBuffer).", 0, true)
            stopSelf(); return
        }
        val bufferSize = maxOf(minBuffer * 2, sampleRate)
        val audioFormat = AudioFormat.Builder().setEncoding(encoding).setSampleRate(sampleRate).setChannelMask(channelMask).build()
        val built = AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(bufferSize)
            .setAudioPlaybackCaptureConfig(config)
            .build()
        if (built.state != AudioRecord.STATE_INITIALIZED) {
            built.release()
            broadcast("AudioRecord no pudo inicializar la captura interna.", 0, true)
            stopSelf(); return
        }
        recorder = built
        try { built.startRecording() } catch (e: Exception) {
            built.release(); recorder = null
            broadcast("No se pudo leer audio interno: ${e.message ?: "error"}", 0, true)
            stopSelf(); return
        }
        running = true
        val queue = ArrayBlockingQueue<ShortArray>(4)
        asrQueue = queue
        broadcast("Captura interna activa. Preparando reconocimiento tailandés…", 0, false)
        asrThread = Thread {
            val engine = ThaiAsrEngine(this)
            asrEngine = engine
            try {
                engine.initialize { message -> broadcast(message, 0, false) }
                while (running) {
                    val segment = queue.poll(1, TimeUnit.SECONDS) ?: continue
                    broadcastTranscript("Fragmento recibido. Intentando reconocer la voz tailandesa…")
                    var sumSquares = 0.0
                    for (sample in segment) { val v = sample.toDouble(); sumSquares += v * v }
                    val segmentRms = kotlin.math.sqrt(sumSquares / segment.size).toInt()
                    broadcast("Analizando 6 segundos de audio (nivel del fragmento: $segmentRms)…", 0, false)
                    val text = try { engine.transcribe(segment) } catch (e: Exception) {
                        broadcast("Error al reconocer voz: ${e.message ?: e.javaClass.simpleName}", 0, false)
                        ""
                    }
                    if (text.isNotBlank()) {
                        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName)
                            .putExtra(EXTRA_STATUS, "Texto tailandés reconocido. Sigue escuchando…")
                            .putExtra(EXTRA_STOPPED, false)
                            .putExtra(EXTRA_TRANSCRIPT, text))
                    } else {
                        broadcast("Fragmento analizado sin texto. Nivel del audio: $segmentRms. Comprueba que haya voz tailandesa clara y deja que termine una frase.", 0, false)
                        broadcastTranscript("El fragmento ya se analizó, pero no se reconocieron palabras. Si esto ocurre con voz clara, envíame una captura de la pantalla completa.")
                    }
                }
            } catch (e: Exception) {
                val message = "No se pudo preparar el reconocimiento: ${e.message ?: e.javaClass.simpleName}"
                broadcast(message, 0, false)
                broadcastTranscript(message)
            } finally { engine.release() }
        }.apply { name = "ThaiOfflineASR"; start() }
        captureThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val buffer = ShortArray(bufferSize / 2)
            var lastBroadcast = 0L
            val chunkSamples = 16000 * 6
            var chunk = ShortArray(chunkSamples)
            var chunkCount = 0
            while (running) {
                val count = try { built.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING) } catch (_: Exception) { -1 }
                if (count > 0) {
                    var offset = 0
                    while (offset < count) {
                        val copyCount = minOf(chunkSamples - chunkCount, count - offset)
                        System.arraycopy(buffer, offset, chunk, chunkCount, copyCount)
                        chunkCount += copyCount
                        offset += copyCount
                        if (chunkCount == chunkSamples) {
                            queue.offer(chunk)
                            chunk = ShortArray(chunkSamples)
                            chunkCount = 0
                        }
                    }
                    var sum = 0.0
                    for (i in 0 until count) { val sample = buffer[i].toDouble(); sum += sample * sample }
                    val rms = sqrt(sum / count).toInt().coerceAtMost(32767)
                    val now = System.currentTimeMillis()
                    if (now - lastBroadcast >= 500) {
                        broadcast(if (rms < 3) "Captura activa, pero no llega audio de TikTok (puede estar bloqueado o pausado)." else "¡Audio interno detectado! La captura está recibiendo sonido.", rms, false)
                        lastBroadcast = now
                    }
                } else if (count < 0) {
                    broadcast("La lectura de audio falló (código $count).", 0, false)
                    try { Thread.sleep(200) } catch (_: InterruptedException) {}
                }
            }
        }.apply { name = "ThaiInternalAudioCapture"; start() }
    }

    private fun startForegroundCompat() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Captura de audio interno", NotificationManager.IMPORTANCE_LOW))
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID).setContentTitle("Traductor Thai-ES").setContentText("Captura de audio interno activa").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Traductor Thai-ES").setContentText("Captura de audio interno activa").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)
    }

    private fun broadcast(message: String, level: Int, stopped: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, message).putExtra(EXTRA_LEVEL, level).putExtra(EXTRA_STOPPED, stopped))
    }

    private fun broadcastTranscript(message: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName)
            .putExtra(EXTRA_STATUS, message)
            .putExtra(EXTRA_STOPPED, false)
            .putExtra(EXTRA_TRANSCRIPT, message))
    }

    private fun stopCapture(message: String) {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        captureThread?.interrupt(); captureThread = null
        asrThread?.interrupt(); asrThread = null
        asrQueue?.clear(); asrQueue = null
        asrEngine = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        broadcast(message, 0, true)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running || recorder != null || projection != null) stopCapture("Captura finalizada.")
        super.onDestroy()
    }
}
