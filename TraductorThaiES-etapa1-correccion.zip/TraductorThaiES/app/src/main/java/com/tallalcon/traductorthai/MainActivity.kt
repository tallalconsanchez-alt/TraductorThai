package com.tallalcon.traductorthai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var listenButton: Button
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private var restartPending = false
    private var lastRecognizedText = ""
    private val audioPermissionRequest = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No se encontró un servicio de reconocimiento de voz en este teléfono."
            listenButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 28))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }

        root.addView(label("Traductor Thai → Español", 26f))
        root.addView(label("ETAPA 1 · Escucha de la transmisión", 16f, Color.rgb(190, 180, 255)))
        root.addView(label("No tienes que hablar. Para esta prueba, reproduce la transmisión por el altavoz del teléfono y sube el volumen para que el micrófono pueda oírla. No uses auriculares. Esta versión no captura directamente el audio interno.", 15f, Color.LTGRAY))
        status = label("Listo. Pulsa «Escuchar transmisión» y concede permiso al micrófono.", 14f, Color.rgb(220, 220, 235))
        root.addView(status, matchWidth())

        listenButton = Button(this).apply {
            text = "Escuchar transmisión"
            setOnClickListener { onListenPressed() }
        }
        root.addView(listenButton, matchWidth())
        root.addView(label("Texto tailandés reconocido", 18f))
        transcript = TextView(this).apply {
            text = "Aquí aparecerá el texto que el servicio de Android consiga reconocer del sonido que capte el micrófono. Todavía no traduce al español."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(16, 18, 16, 18)
            setBackgroundColor(Color.rgb(37, 36, 52))
            gravity = Gravity.START
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Button(this).apply {
            text = "Borrar texto"
            setOnClickListener {
                transcript.text = ""
                lastRecognizedText = ""
            }
        }, matchWidth())
        root.addView(Button(this).apply {
            text = "Probar voz en español"
            setOnClickListener {
                if (ttsReady) tts?.speak("Hola. La prueba de voz en español funciona.", TextToSpeech.QUEUE_FLUSH, null, "test_es")
                else status.text = "El motor de voz en español todavía se está iniciando."
            }
        }, matchWidth())
        root.addView(label("Esta prueba usa el micrófono y el servicio de voz de Android; puede necesitar Internet. La escucha intenta reanudarse automáticamente, pero Android puede limitarla.", 13f, Color.LTGRAY), matchWidth())
        setContentView(root)
    }

    private fun onListenPressed() {
        if (listening) {
            stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        startContinuousListening()
    }

    private fun createRecognizerIfNeeded() {
        if (speechRecognizer != null) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (listening) status.text = "Escuchando el sonido del altavoz… no tienes que hablar."
                }
                override fun onBeginningOfSpeech() {
                    if (listening) status.text = "Se detectó sonido; intentando reconocer tailandés…"
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    if (listening) status.text = "Procesando un fragmento de audio…"
                }
                override fun onError(error: Int) {
                    if (!listening) return
                    status.text = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso del micrófono. Detén y vuelve a iniciar después de concederlo."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "El servicio de voz puede necesitar Internet; reintentando…"
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No se reconoció voz en este fragmento; sigo escuchando…"
                        else -> "La escucha se interrumpió; intentando reanudar…"
                    }
                    scheduleRestart()
                }
                override fun onResults(results: Bundle?) {
                    if (!listening) return
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (text.isNotEmpty() && text != lastRecognizedText) {
                        val current = transcript.text.toString()
                        transcript.text = if (current.startsWith("Aquí aparecerá")) text else if (current.isBlank()) text else "$current\n\n$text"
                        lastRecognizedText = text
                    }
                    status.text = "Escucha activa. Si no aparece texto, sube el volumen y comprueba que la transmisión salga por el altavoz."
                    scheduleRestart()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (listening && !partial.isNullOrBlank()) status.text = "Audio detectado; reconocimiento en curso…"
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun recognitionIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "กำลังฟังเสียงภาษาไทย")
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
    }

    private fun startContinuousListening() {
        try {
            createRecognizerIfNeeded()
            listening = true
            restartPending = false
            listenButton.text = "Detener escucha"
            status.text = "Iniciando escucha… reproduce el directo por el altavoz."
            if (transcript.text.toString().startsWith("Aquí aparecerá")) transcript.text = "Escuchando la transmisión…"
            speechRecognizer?.startListening(recognitionIntent())
        } catch (e: Exception) {
            listening = false
            listenButton.text = "Escuchar transmisión"
            status.text = "No se pudo iniciar el reconocimiento: ${e.localizedMessage ?: "error desconocido"}"
        }
    }

    private fun scheduleRestart() {
        if (!listening || restartPending) return
        restartPending = true
        handler.postDelayed({
            restartPending = false
            if (listening) {
                try {
                    speechRecognizer?.startListening(recognitionIntent())
                } catch (_: Exception) {
                    try { speechRecognizer?.cancel() } catch (_: Exception) {}
                    handler.postDelayed({ if (listening) startContinuousListening() }, 900L)
                }
            }
        }, 700L)
    }

    private fun stopListening() {
        listening = false
        restartPending = false
        handler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        listenButton.text = "Escuchar transmisión"
        status.text = "Escucha detenida."
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Error al recibir audio. Comprueba el micrófono."
        SpeechRecognizer.ERROR_CLIENT -> "El servicio de voz detuvo la solicitud."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso para usar el micrófono."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Error de conexión; este servicio puede necesitar Internet."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No se reconoció ninguna frase."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocimiento está ocupado."
        SpeechRecognizer.ERROR_SERVER -> "El servicio de reconocimiento devolvió un error."
        else -> "No se pudo reconocer el audio (código $error)."
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startContinuousListening()
            else Toast.makeText(this, "Necesitamos permiso del micrófono para escuchar el sonido de la transmisión.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "ES"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
