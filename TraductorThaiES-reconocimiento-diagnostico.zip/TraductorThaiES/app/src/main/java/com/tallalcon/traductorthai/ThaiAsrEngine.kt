package com.tallalcon.traductorthai

import android.content.Context
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Offline Thai speech recognition. The model is downloaded once, then stays in app storage. */
class ThaiAsrEngine(private val context: Context) {
    private var recognizer: OfflineRecognizer? = null

    fun initialize(onStatus: (String) -> Unit) {
        val modelDir = File(context.filesDir, "thai-zipformer")
        val encoder = File(modelDir, "encoder-epoch-12-avg-5.int8.onnx")
        val decoder = File(modelDir, "decoder-epoch-12-avg-5.onnx")
        val joiner = File(modelDir, "joiner-epoch-12-avg-5.int8.onnx")
        val tokens = File(modelDir, "tokens.txt")
        if (!(encoder.exists() && decoder.exists() && joiner.exists() && tokens.exists())) {
            modelDir.mkdirs()
            val archive = File(context.cacheDir, "thai-model.tar.bz2")
            onStatus("Descargando modelo tailandés (aprox. 150 MB). Usa Wi-Fi; solo se hace una vez.")
            download(URL(MODEL_URL), archive) { bytes, total ->
                if (total > 0) onStatus("Descargando modelo tailandés: ${bytes / 1_000_000} / ${total / 1_000_000} MB")
            }
            onStatus("Preparando modelo tailandés…")
            extractModel(archive, modelDir)
            archive.delete()
        }
        onStatus("Cargando reconocimiento tailandés en el teléfono…")
        val config = OfflineRecognizerConfig(
            modelConfig = OfflineModelConfig(
                transducer = OfflineTransducerModelConfig(
                    encoder = encoder.absolutePath,
                    decoder = decoder.absolutePath,
                    joiner = joiner.absolutePath,
                ),
                tokens = tokens.absolutePath,
                numThreads = 2,
                provider = "cpu",
            ),
        )
        recognizer = OfflineRecognizer(config = config)
        onStatus("Reconocimiento tailandés listo; escuchando audio de TikTok.")
    }

    fun transcribe(pcm: ShortArray): String {
        val r = recognizer ?: return ""
        var squareSum = 0.0
        for (sample in pcm) {
            val normalized = sample / 32768.0
            squareSum += normalized * normalized
        }
        val inputRms = kotlin.math.sqrt(squareSum / pcm.size).toFloat()
        // TikTok playback capture can be quieter than microphone recordings. Apply
        // modest automatic gain, capped to avoid amplifying silence excessively.
        val gain = if (inputRms > 0.001f) minOf(5.0f, 0.06f / inputRms) else 1.0f
        val samples = FloatArray(pcm.size) { (pcm[it] / 32768.0f * gain).coerceIn(-1.0f, 1.0f) }
        if (inputRms < 0.0005f) return ""
        val stream = r.createStream()
        return try {
            stream.acceptWaveform(samples, sampleRate = 16000)
            r.decode(stream)
            r.getResult(stream).text.trim()
        } finally {
            stream.release()
        }
    }

    fun release() {
        try { recognizer?.release() } catch (_: Exception) {}
        recognizer = null
    }

    private fun download(url: URL, target: File, progress: (Long, Long) -> Unit) {
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("Descarga del modelo: HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var count: Int
                    var downloaded = 0L
                    var lastReport = 0L
                    while (input.read(buffer).also { count = it } >= 0) {
                        if (count == 0) continue
                        output.write(buffer, 0, count)
                        downloaded += count
                        if (downloaded - lastReport >= 5_000_000) {
                            progress(downloaded, total)
                            lastReport = downloaded
                        }
                    }
                    progress(downloaded, total)
                }
            }
        } finally { connection.disconnect() }
    }

    private fun extractModel(archive: File, destination: File) {
        val needed = setOf(
            "encoder-epoch-12-avg-5.int8.onnx",
            "decoder-epoch-12-avg-5.onnx",
            "joiner-epoch-12-avg-5.int8.onnx",
            "tokens.txt",
        )
        TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            var entry = tar.nextTarEntry
            while (entry != null) {
                val name = File(entry.name).name
                if (!entry.isDirectory && name in needed) {
                    val out = File(destination, name)
                    FileOutputStream(out).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val count = tar.read(buffer)
                            if (count <= 0) break
                            output.write(buffer, 0, count)
                        }
                    }
                }
                entry = tar.nextTarEntry
            }
        }
        needed.forEach { if (!File(destination, it).exists()) error("El modelo descargado no contiene $it") }
    }

    companion object {
        private const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-zipformer-thai-2024-06-20.tar.bz2"
    }
}
