package com.tallalcon.traductorthai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(18, 18, 28))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 16)
        }
        root.addView(label("Traductor Thai → Español", 26f))
        root.addView(label("Subtítulos y voz para audio de otras aplicaciones", 16f, Color.LTGRAY))
        status = label("Estado: prototipo inicial instalado correctamente.\n\nLa captura y transcripción del audio todavía no están activadas.", 15f, Color.rgb(220, 220, 235))
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val testButton = Button(this).apply {
            text = "Probar voz en español"
            setOnClickListener {
                if (ttsReady) tts?.speak("Hola. La voz en español funciona.", TextToSpeech.QUEUE_FLUSH, null, "test_es")
                else status.text = "El motor de voz todavía se está iniciando. Inténtalo de nuevo."
            }
        }
        root.addView(testButton, matchWidth())

        val overlayButton = Button(this).apply {
            text = "Permitir ventana flotante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    status.text = "Permiso de ventana flotante concedido. La burbuja de subtítulos se añadirá en la siguiente etapa."
                }
            }
        }
        root.addView(overlayButton, matchWidth())
        root.addView(label("Siguiente etapa: captura de audio interno, reconocimiento del tailandés y traducción al español sin conexión.", 13f, Color.LTGRAY), matchWidth())
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "ES"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
