package com.tallalcon.traductorthai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var listenButton: Button
    private var listening = false
    private val audioPermissionRequest = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No se encontró un servicio de reconocimiento de voz en este teléfono. Instala o activa un servicio compatible con reconocimiento de voz y vuelve a intentarlo."
            listenButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 28))
        }

        fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }

        root.addView(label("Traductor Thai → Español", 26f))
        root.addView(label("ETAPA 1 · Reconocimiento de voz", 16f, Color.rgb(190, 180, 255)))
        root.addView(label("Habla en tailandés cerca del micrófono. La aplicación intentará convertir tu voz en texto.", 15f, Color.LTGRAY))

        status = label("Estado: listo. Pulsa ‘Escuchar tailandés’ y concede permiso al micrófono.", 14f, Color.rgb(220, 220, 235))
        root.addView(status, matchWidth())

        listenButton = Button(this).apply {
            text = "Escuchar tailandés"
            setOnClickListener { onListenPressed() }
        }
        root.addView(listenButton, matchWidth())

        root.addView(label("Texto reconocido", 18f))
        transcript = TextView(this).apply {
            text = "Aquí aparecerá el texto tailandés reconocido.\n\nNota: esta etapa usa el servicio de voz disponible en Android; puede necesitar Internet y no traduce todavía al español."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(16, 18, 16, 18)
            setBackgroundColor(Color.rgb(37, 36, 52))
            gravity = Gravity.START
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val clearButton = Button(this).apply {
            text = "Borrar texto"
            setOnClickListener { transcript.text = "" }
        }
        root.addView(clearButton, matchWidth())

        val voiceButton = Button(this).apply {
            text = "Probar voz en español"
            setOnClickListener {
                if (ttsReady) tts?.speak("Hola. La prueba de voz en español funciona.", TextToSpeech.QUEUE_FLUSH, null, "test_es")
                else status.text = "El motor de voz en español todavía se está iniciando. Inténtalo de nuevo."
            }
        }
        root.addView(voiceButton, matchWidth())

        root.addView(label("Próxima etapa: traducir el texto tailandés al español.", 13f, Color.LTGRAY), matchWidth())
        setContentView(root)
    }

    private fun onListenPressed() {
        if (listening) {
            stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No hay un servicio de reconocimiento de voz disponible."
            return
        }
        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                    recognizer.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            status.text = "Escuchando… habla en tailandés."
                        }
                        override fun onBeginningOfSpeech() {
                            status.text = "Te estoy escuchando…"
                        }
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            status.text = "Procesando el audio…"
                        }
                        override fun onError(error: Int) {
                            listening = false
                            listenButton.text = "Escuchar tailandés"
                            status.text = errorMessage(error)
                        }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) {
                                transcript.text = matches.joinToString("\n\nAlternativa: ")
                                status.text = "Reconocimiento terminado. Puedes volver a escuchar."
                            } else {
                                status.text = "No se detectó una frase. Inténtalo de nuevo hablando con claridad."
                            }
                            listening = false
                            listenButton.text = "Escuchar tailandés"
                        }
                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) transcript.text = matches.first()
                        }
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดภาษาไทย")
            }
            listening = true
            listenButton.text = "Detener escucha"
            transcript.text = "Escuchando tailandés…"
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            listening = false
            listenButton.text = "Escuchar tailandés"
            status.text = "No se pudo iniciar el reconocimiento: ${e.localizedMessage ?: "error desconocido"}"
        }
    }

    private fun stopListening() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        listening = false
        listenButton.text = "Escuchar tailandés"
        status.text = "Escucha detenida."
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Error al recibir audio. Comprueba el micrófono."
        SpeechRecognizer.ERROR_CLIENT -> "El servicio de voz detuvo la solicitud. Inténtalo otra vez."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso para usar el micrófono."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Error de conexión. Este servicio de voz puede necesitar Internet."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No se reconoció ninguna frase. Habla un poco más y vuelve a intentarlo."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocimiento está ocupado. Espera unos segundos y vuelve a intentarlo."
        SpeechRecognizer.ERROR_SERVER -> "El servicio de reconocimiento devolvió un error. Inténtalo de nuevo."
        else -> "No se pudo reconocer el audio (código $error). Inténtalo otra vez."
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
            else Toast.makeText(this, "Necesitamos permiso del micrófono para reconocer el tailandés.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "ES"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
