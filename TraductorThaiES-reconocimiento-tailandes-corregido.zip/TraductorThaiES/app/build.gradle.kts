import java.net.URL
import java.net.HttpURLConnection

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tallalcon.traductorthai"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    defaultConfig {
        applicationId = "com.tallalcon.traductorthai"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0"
    }
}


val sherpaAarFile = layout.projectDirectory.file("libs/sherpa-onnx-1.13.8.aar").asFile
val downloadSherpaAar by tasks.registering {
    outputs.file(sherpaAarFile)
    doLast {
        if (!sherpaAarFile.exists() || sherpaAarFile.length() < 1_000_000L) {
            sherpaAarFile.parentFile.mkdirs()
            val url = URL("https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-1.13.8.aar")
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 20000
            connection.readTimeout = 120000
            connection.instanceFollowRedirects = true
            try {
                connection.inputStream.use { input -> sherpaAarFile.outputStream().use { output -> input.copyTo(output) } }
                if (sherpaAarFile.length() < 1_000_000L) error("La biblioteca de reconocimiento descargada está incompleta")
            } finally { connection.disconnect() }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadSherpaAar) }

dependencies {
    implementation(files(sherpaAarFile))
    implementation("org.apache.commons:commons-compress:1.27.1")
}
